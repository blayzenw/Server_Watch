This works with python 2.7.6
http://www.python.org/ftp/python/2.7.6/python-2.7.6.msi